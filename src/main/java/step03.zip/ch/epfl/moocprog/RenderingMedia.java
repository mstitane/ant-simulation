package ch.epfl.moocprog;

/**
 * Interface de décrire de façon générique tous les supports
 * de rendu, sans dépendre d'une implémentation en particulier.
 *
 */
public interface RenderingMedia {
}
