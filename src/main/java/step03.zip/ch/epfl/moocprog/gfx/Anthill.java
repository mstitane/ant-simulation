package ch.epfl.moocprog.gfx;

public class Anthill {
}
