package ch.epfl.moocprog;

public interface FoodGeneratorEnvironmentView {

    abstract void addFood(Food food);
}
